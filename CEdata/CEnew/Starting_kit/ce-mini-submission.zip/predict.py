# Template for submission of code in the Fast Causation Coefficient Challenge.
# Original code: Ben Hamner, Kaggle, March 2013
# https://github.com/benhamner/CauseEffectPairsChallenge
# Modified by Ivan Judson and Christophe Poulain, Microsoft, December 2013
# Modified by Isabelle Guyon, ChaLearn, March 2014

# ALL INFORMATION, SOFTWARE, DOCUMENTATION, AND DATA ARE PROVIDED "AS-IS". 
# ISABELLE GUYON, CHALEARN, KAGGLE, MOCROSOFT AND/OR OTHER ORGANIZERS DISCLAIM
# ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR ANY PARTICULAR PURPOSE, AND THE
# WARRANTY OF NON-INFRIGEMENT OF ANY THIRD PARTY'S INTELLECTUAL PROPERTY RIGHTS. 
# IN NO EVENT SHALL ISABELLE GUYON AND/OR OTHER ORGANIZERS BE LIABLE FOR ANY SPECIAL, 
# INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER ARISING OUT OF OR IN
# CONNECTION WITH THE USE OR PERFORMANCE OF SOFTWARE, DOCUMENTS, MATERIALS, 
# PUBLICATIONS, OR INFORMATION MADE AVAILABLE FOR THE CHALLENGE. 

import csv
import sys
import os
import os.path
import pandas as pd
import numpy as np
import pickle
import glob

def main():

	# The code should assume that the input data directory (named input_dir) 
	# contains two files:
	# [basename]_pairs.csv and [basename]_publicinfo.csv,
	# where [basename] can be substituted with anything.
	# This small example ignores the file [basename]_publicinfo.csv, which contains
	# information about variable types (numerical, binary, categorical).
	# The causation coefficients predicted [basename]_predict.csv are placed in the
	# output data directory named output_dir.

	input_dir = sys.argv[1]
	output_dir = sys.argv[2]

	# Get the file names
	filename_pairs = glob.glob(os.path.join(input_dir, '*_pairs.csv'))
	if len(filename_pairs)!=1:
		print('No or multiple pairs.scv files')
		exit(1)
	filename_pairs = filename_pairs[0]
	filename_info = glob.glob(os.path.join(input_dir, '*_publicinfo.csv'))
	if len(filename_info)!=1:
		print('No or multiple publicinfo.scv files')
		exit(1)
	filename_info = filename_info[0]
	basename = filename_pairs[:-filename_pairs[::-1].index('_')-1]
	if  filename_info[:-filename_info[::-1].index('_')-1] != basename:
		print('Different basenames in publicinfo.csv and pairs.csv files')
		exit(1)
		
	# Remove the path name
	try:
		dataset = basename[-basename[::-1].index(os.sep):]
	except:
		dataset = basename

	# Read the data (cause effect pairs) in a Panda data frame
	print("Reading the " + dataset + " pairs")
	df = pd.read_csv(filename_pairs, index_col="SampleID")
	parse_cell = lambda cell: np.fromstring(cell, dtype=np.float, sep=" ")
	data_frame = df.applymap(parse_cell)

	# If needed also read filename_info (not used here).

	# The following allows Codalab to find your trained classifier 
	# or predictive model (used to calculate the causation coefficient.
	# In this example, the trained classifier is a random forest save as 
	# "basic_python_benchmark.pickle"
	print("Loading the classifier")
	prog_dir = os.path.dirname(os.path.abspath(__file__))
	in_dir = os.path.join(prog_dir, "basic_python_benchmark.pickle")
	classifier = pickle.load(open(in_dir))

	# If you want to get the full example with classifier training,
	# go to: https://github.com/benhamner/CauseEffectPairsChallenge

	# The classifier predict method gets called. It needs features.py
	# which extracts features from the joint distribution of the two
	# variables, then used by the random forest.
	print("Making predictions") 
	predictions = classifier.predict(data_frame)
	predictions = predictions.flatten()

	# The predicted causation coefficients get written to the output file.
	# Important: the solution must end with "predict.csv'
	output_filename = dataset + "_predict.csv"
	print("Writing predictions to " + output_filename)
	submission_dir = os.path.join(output_dir, output_filename)
	writer = csv.writer(open(submission_dir, "w"), lineterminator="\n")
	rows = [x for x in zip(data_frame.index, predictions)]
	writer.writerow(("SampleID", "Target"))
	writer.writerows(rows)

# Now execute the main function
if __name__=="__main__":
    main()